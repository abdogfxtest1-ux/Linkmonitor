package com.linkmonitor

import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Store(private val dir: File) {
    init { dir.mkdirs() }

    fun append(o: JSONObject) {
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        File(dir, "$day.jsonl").appendText(o.toString() + "\n")
    }

    fun all(): List<JSONObject> =
        (dir.listFiles() ?: emptyArray()).filter { it.name.endsWith(".jsonl") }.sortedBy { it.name }
            .flatMap { f -> f.readLines().mapNotNull { l -> try { JSONObject(l) } catch (e: Exception) { null } } }

    fun csv(): String {
        val cols = listOf("ts", "round", "site", "state", "status", "loadMs", "channel", "ip", "detail", "shot")
        val sb = StringBuilder("\uFEFF" + cols.joinToString(",") + "\n")
        for (o in all()) {
            sb.append(cols.joinToString(",") { "\"" + o.optString(it).replace("\"", "\"\"") + "\"" }).append("\n")
        }
        return sb.toString()
    }
}
