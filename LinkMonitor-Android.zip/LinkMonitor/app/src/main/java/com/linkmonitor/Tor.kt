package com.linkmonitor

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import net.freehaven.tor.control.TorControlConnection
import org.torproject.jni.TorService
import kotlin.coroutines.resume

/** Tor مدمج في التطبيق (مكتبة Guardian Project) — بدون حساب وبدون تطبيق خارجي. */
class Tor(private val ctx: Context) {
    private var service: TorService? = null
    private var conn: TorControlConnection? = null
    private var bound = false
    var socksPort = 0
        private set

    private val sc = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) { service = (b as TorService.LocalBinder).service }
        override fun onServiceDisconnected(n: ComponentName) { service = null; conn = null }
    }

    fun start() { if (!bound) bound = ctx.bindService(Intent(ctx, TorService::class.java), sc, Context.BIND_AUTO_CREATE) }

    fun stop() {
        if (bound) { try { ctx.unbindService(sc) } catch (e: Exception) {} }
        bound = false; service = null; conn = null; socksPort = 0
    }

    /** ينتظر اكتمال اتصال Tor (من 20 ثانية لدقيقتين أول مرة). */
    suspend fun waitReady(timeoutMs: Long, onProgress: suspend (Int) -> Unit): Boolean {
        val t0 = SystemClock.elapsedRealtime()
        while (SystemClock.elapsedRealtime() - t0 < timeoutMs) {
            val pct = withContext(Dispatchers.IO) {
                try {
                    if (conn == null) conn = service?.torControlConnection
                    val bp = conn?.getInfo("status/bootstrap-phase") ?: ""
                    Regex("PROGRESS=(\\d+)").find(bp)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                } catch (e: Exception) { conn = null; 0 }
            }
            onProgress(pct)
            if (pct >= 100) {
                socksPort = withContext(Dispatchers.IO) {
                    try { Regex(":(\\d+)").find(conn?.getInfo("net/listeners/socks") ?: "")?.groupValues?.get(1)?.toIntOrNull() }
                    catch (e: Exception) { null }
                } ?: 9050
                return true
            }
            delay(1000)
        }
        return false
    }

    /** يحدد دولة الخروج (مثلاً "de") ويطلب مسار جديد. */
    suspend fun useExit(cc: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val c = conn ?: return@withContext false
            c.setConf("ExitNodes", "{${cc.lowercase()}}")
            c.setConf("StrictNodes", "1")
            c.signal("NEWNYM")
            true
        } catch (e: Exception) { false }
    }
}

/** تمرير كل WebViews عبر SOCKS (Tor) أو إلغاء التمرير. */
object WebProxy {
    private fun ok() = WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)

    suspend fun set(ctx: Context, port: Int): Boolean {
        if (!ok()) return false
        suspendCancellableCoroutine<Unit> { c ->
            ProxyController.getInstance().setProxyOverride(
                ProxyConfig.Builder().addProxyRule("socks5://127.0.0.1:$port").build(),
                ContextCompat.getMainExecutor(ctx)
            ) { c.resume(Unit) }
        }
        return true
    }

    suspend fun clear(ctx: Context) {
        if (!ok()) return
        suspendCancellableCoroutine<Unit> { c ->
            ProxyController.getInstance().clearProxyOverride(ContextCompat.getMainExecutor(ctx)) { c.resume(Unit) }
        }
    }
}
