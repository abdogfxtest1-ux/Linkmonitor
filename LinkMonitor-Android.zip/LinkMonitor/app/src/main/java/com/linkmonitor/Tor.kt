package com.linkmonitor

import IPtProxy.Controller
import IPtProxy.IPtProxy
import IPtProxy.OnTransportEvents
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import net.freehaven.tor.control.TorControlConnection
import org.json.JSONObject
import org.torproject.jni.TorService
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume

/**
 * Tor مدمج في التطبيق (مكتبة Guardian Project) — بدون حساب وبدون تطبيق خارجي.
 * بيدخل عن طريق Bridges (obfs4 + Snowflake) لأن مزوّدين كتير (زي مصر) قافلين Tor المباشر.
 */
class Tor(private val ctx: Context) {
    private var service: TorService? = null
    private var conn: TorControlConnection? = null
    private var bound = false
    private var pt: Controller? = null
    var socksPort = 0
        private set
    var lastPct = 0
        private set
    var bridgeInfo = ""
        private set

    private val sc = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) { service = (b as TorService.LocalBinder).service }
        override fun onServiceDisconnected(n: ComponentName) { service = null; conn = null }
    }

    suspend fun start() {
        if (bound) return
        withContext(Dispatchers.IO) { writeTorrc() }
        bound = ctx.bindService(Intent(ctx, TorService::class.java), sc, Context.BIND_AUTO_CREATE)
    }

    fun stop() {
        if (bound) { try { ctx.unbindService(sc) } catch (e: Exception) {} }
        try { pt?.stop(IPtProxy.Obfs4) } catch (e: Exception) {}
        try { pt?.stop(IPtProxy.Snowflake) } catch (e: Exception) {}
        bound = false; service = null; conn = null; socksPort = 0; lastPct = 0
    }

    /** يجيب Bridges جديدة من Tor نفسه (حسب دولة الاتصال)، ولو فشل يستخدم آخر نسخة أو المدمجة. */
    private fun bridges(): List<String> {
        val cache = File(ctx.filesDir, "bridges.txt")
        fun post(path: String, body: String): JSONObject {
            val c = URL("https://bridges.torproject.org/moat/circumvention/$path").openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 10000; c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/vnd.api+json")
            c.outputStream.use { it.write(body.toByteArray()) }
            try { return JSONObject(c.inputStream.bufferedReader().readText()) } finally { c.disconnect() }
        }
        val got = mutableListOf<String>()
        try {
            val s = post("settings", "{\"transports\":[\"obfs4\",\"snowflake\"]}").optJSONArray("settings")
            for (i in 0 until (s?.length() ?: 0)) {
                val a = s!!.getJSONObject(i).optJSONObject("bridges")?.optJSONArray("bridge_strings") ?: continue
                for (j in 0 until a.length()) got.add(a.getString(j))
            }
            if (got.isEmpty()) {
                val b = post("builtin", "{}")
                for (k in listOf("obfs4", "snowflake")) b.optJSONArray(k)?.let { a -> for (j in 0 until a.length()) got.add(a.getString(j)) }
            }
        } catch (e: Exception) {}
        val list = got.filter { it.startsWith("obfs4 ") || it.startsWith("snowflake ") }.distinct()
        if (list.isNotEmpty()) { try { cache.writeText(list.joinToString("\n")) } catch (e: Exception) {}; bridgeInfo = "bridges محدّثة"; return list }
        val old = try { cache.readLines().filter { it.isNotBlank() } } catch (e: Exception) { emptyList() }
        if (old.isNotEmpty()) { bridgeInfo = "bridges محفوظة"; return old }
        bridgeInfo = "bridges مدمجة"
        return BUILTIN
    }

    private fun writeTorrc() {
        val list = bridges()
        val c = pt ?: IPtProxy.newController(File(ctx.filesDir, "pt").apply { mkdirs() }.absolutePath, false, false, "ERROR",
            object : OnTransportEvents {
                override fun connected(name: String?) {}
                override fun error(name: String?, e: Exception?) {}
                override fun stopped(name: String?, e: Exception?) {}
            }).also { pt = it }
        list.firstOrNull { it.startsWith("snowflake ") }?.let { sf ->
            fun arg(k: String) = Regex("\\b$k=(\\S+)").find(sf)?.groupValues?.get(1)
            arg("url")?.let { c.snowflakeBrokerUrl = it }
            arg("fronts")?.let { c.snowflakeFrontDomains = it }
            arg("ice")?.let { c.snowflakeIceServers = it }
        }
        val sb = StringBuilder("UseBridges 1\n")
        for (name in listOf(IPtProxy.Obfs4, IPtProxy.Snowflake)) {
            try {
                c.start(name, "")
                val port = c.port(name)
                if (port > 0) sb.append("ClientTransportPlugin $name socks5 127.0.0.1:$port\n")
            } catch (e: Exception) {}
        }
        val usable = list.filter { b -> sb.contains("ClientTransportPlugin ${b.substringBefore(' ')} ") }
        // من غير أي transport شغال نرجع لـ Tor العادي بدل ما نقفله
        if (usable.isEmpty()) { TorService.getTorrc(ctx).writeText(""); bridgeInfo = "بدون bridges"; return }
        usable.forEach { sb.append("Bridge ").append(it).append("\n") }
        TorService.getTorrc(ctx).writeText(sb.toString())
    }

    /** ينتظر اكتمال اتصال Tor (من 20 ثانية لـ 3 دقايق أول مرة مع الـ bridges). */
    suspend fun waitReady(timeoutMs: Long, onProgress: suspend (Int) -> Unit): Boolean {
        val t0 = SystemClock.elapsedRealtime()
        while (SystemClock.elapsedRealtime() - t0 < timeoutMs) {
            val pct = withContext(Dispatchers.IO) {
                try {
                    if (conn == null) conn = service?.torControlConnection
                    val bp = conn?.getInfo("status/bootstrap-phase") ?: ""
                    Regex("PROGRESS=(\\d+)").find(bp)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                } catch (e: Exception) { conn = null; 0 }
            }
            lastPct = maxOf(lastPct, pct)
            onProgress(pct)
            if (pct >= 100) {
                socksPort = withContext(Dispatchers.IO) {
                    try { Regex(":(\\d+)").find(conn?.getInfo("net/listeners/socks") ?: "")?.groupValues?.get(1)?.toIntOrNull() }
                    catch (e: Exception) { null }
                } ?: 9050
                return true
            }
            delay(1000)
        }
        return false
    }

    /** يحدد دولة الخروج (مثلاً "de") ويطلب مسار جديد. */
    suspend fun useExit(cc: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val c = conn ?: return@withContext false
            c.setConf("ExitNodes", "{${cc.lowercase()}}")
            c.setConf("StrictNodes", "1")
            c.signal("NEWNYM")
            true
        } catch (e: Exception) { false }
    }

    companion object {
        // نسخة احتياطية من bridges.torproject.org/moat/circumvention/builtin (أكتوبر 2026)
        private val BUILTIN = listOf(
            "obfs4 45.145.95.6:27015 C5B7CD6946FF10C5B3E89691A7D3F2C122D2117C cert=TD7PbUO0/0k6xYHMPW3vJxICfkMZNdkRrb63Zhl5j9dW3iRGiCx0A7mPhe5T2EDzQ35+Zw iat-mode=0",
            "obfs4 212.83.43.95:443 BFE712113A72899AD685764B211FACD30FF52C31 cert=ayq0XzCwhpdysn5o0EyDUbmSOx3X/oTEbzDMvczHOdBJKlvIdHHLJGkZARtT4dcBFArPPg iat-mode=1",
            "obfs4 37.218.245.14:38224 D9A82D2F9C2F65A18407B1D2B764F130847F8B5D cert=bjRaMrr1BRiAW8IE9U5z27fQaYgOhX1UCmOpg2pFpoMvo6ZgQMzLsaTzzQNTlm7hNcb+Sg iat-mode=0",
            "obfs4 146.57.248.225:22 10A6CD36A537FCE513A322361547444B393989F0 cert=K1gDtDAIcUfeLqbstggjIw2rtgIKqdIhUlHp82XRqNSq/mtAjp1BIC9vHKJ2FAEpGssTPw iat-mode=0",
            "snowflake 192.0.2.4:80 8838024498816A039FCBBAB14E6F40A0843051FA fingerprint=8838024498816A039FCBBAB14E6F40A0843051FA url=https://1098762253.rsc.cdn77.org/ fronts=app.datapacket.com,www.datapacket.com ice=stun:stun.epygi.com:3478,stun:stun.uls.co.za:3478,stun:stun.voipgate.com:3478,stun:stun.mixvoip.com:3478,stun:stun.telnyx.com:3478,stun:stun.hot-chilli.net:3478,stun:stun.fitauto.ru:3478,stun:stun.m-online.net:3478 utls-imitate=hellorandomizedalpn",
            "snowflake 192.0.2.3:80 2B280B23E1107BB62ABFC40DDCC8824814F80A72 fingerprint=2B280B23E1107BB62ABFC40DDCC8824814F80A72 url=https://1098762253.rsc.cdn77.org/ fronts=app.datapacket.com,www.datapacket.com ice=stun:stun.epygi.com:3478,stun:stun.uls.co.za:3478,stun:stun.voipgate.com:3478,stun:stun.mixvoip.com:3478,stun:stun.telnyx.com:3478,stun:stun.hot-chilli.net:3478,stun:stun.fitauto.ru:3478,stun:stun.m-online.net:3478 utls-imitate=hellorandomizedalpn",
        )
    }
}

/** تمرير كل WebViews عبر SOCKS (Tor) أو إلغاء التمرير. */
object WebProxy {
    private fun ok() = WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)

    suspend fun set(ctx: Context, port: Int): Boolean {
        if (!ok()) return false
        suspendCancellableCoroutine<Unit> { c ->
            ProxyController.getInstance().setProxyOverride(
                ProxyConfig.Builder().addProxyRule("socks5://127.0.0.1:$port").build(),
                ContextCompat.getMainExecutor(ctx)
            ) { c.resume(Unit) }
        }
        return true
    }

    suspend fun clear(ctx: Context) {
        if (!ok()) return
        suspendCancellableCoroutine<Unit> { c ->
            ProxyController.getInstance().clearProxyOverride(ContextCompat.getMainExecutor(ctx)) { c.resume(Unit) }
        }
    }
}
