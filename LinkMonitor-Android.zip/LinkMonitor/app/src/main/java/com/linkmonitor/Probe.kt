package com.linkmonitor

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.webkit.*
import android.widget.FrameLayout
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/** فحص موقع واحد داخل WebView ظاهر في [box] (هو شاشة المعاينة). */
class Probe(private val ctx: Context, private val box: FrameLayout) {
    class Res(val state: String, val status: Int, val loadMs: Long, val detail: String, val shot: Bitmap?)

    private suspend fun js(wv: WebView, code: String): String? =
        suspendCancellableCoroutine { c -> wv.evaluateJavascript(code) { c.resume(it) } }

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun run(url: String, monitorSec: Int, onTick: (Int) -> Unit): Res {
        val wv = WebView(ctx)
        try {
            box.removeAllViews()
            box.addView(wv, FrameLayout.LayoutParams(-1, -1))
            wv.settings.javaScriptEnabled = true
            wv.settings.domStorageEnabled = true
            wv.settings.cacheMode = WebSettings.LOAD_NO_CACHE
            wv.clearCache(true); wv.clearHistory()

            var status = 0
            var blocked = false
            var err: String? = null
            var gone = false
            var retrying = false
            var retried = false
            val loaded = CompletableDeferred<Unit>()

            wv.webViewClient = object : WebViewClient() {
                override fun onReceivedHttpError(v: WebView, r: WebResourceRequest, resp: WebResourceResponse) {
                    if (!r.isForMainFrame) return
                    status = resp.statusCode
                    val h = resp.responseHeaders ?: emptyMap()
                    val cf = h.keys.any { it.equals("cf-mitigated", true) } ||
                        (status == 503 && h.any { it.key.equals("server", true) && it.value.contains("cloudflare", true) })
                    blocked = status == 403 || status == 429 || cf
                }
                override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                    if (!r.isForMainFrame) return
                    // بعد تبديل الـ VPN/Tor أول طلب ممكن يقع بـ ERR_NETWORK_CHANGED؛ ده مش عطل في الموقع فنعيد مرة
                    if (!retried && !loaded.isCompleted && e.description.toString().contains("NETWORK_CHANGED")) {
                        retried = true; retrying = true
                        v.postDelayed({ retrying = false; v.reload() }, 800)
                        return
                    }
                    err = "${e.errorCode} ${e.description}"
                    loaded.complete(Unit)
                }
                override fun onPageFinished(v: WebView, u: String?) { if (!retrying) loaded.complete(Unit) }
                override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                    gone = true; return true
                }
            }

            val t0 = SystemClock.elapsedRealtime()
            wv.loadUrl(url)
            val done = withTimeoutOrNull(15000) { loaded.await() }
            val ms = SystemClock.elapsedRealtime() - t0

            fun shot(): Bitmap? =
                if (wv.width > 0 && wv.height > 0)
                    Bitmap.createBitmap(wv.width, wv.height, Bitmap.Config.ARGB_8888).also { wv.draw(Canvas(it)) }
                else null
            fun bad(state: String, detail: String) = Res(state, status, ms, detail, shot())

            if (done == null) return bad("timeout", "15s")
            err?.let { return bad("http", it) }
            if (status >= 400) return bad(if (blocked) "blocked" else "http", "HTTP $status")

            err = null; status = 0
            for (i in 1..monitorSec) {
                delay(1000)
                onTick(monitorSec - i)
                if (gone) return bad("mid", "renderer crash")
                err?.let { return bad("mid", it) }
                if (i % 5 == 0) {
                    val r = js(wv, "(function(){var b=document.body;if(!b)return 0;return (b.innerText||'').trim().length+b.querySelectorAll('img,canvas,video,svg,iframe').length})()")
                    if (r == "0") return bad("mid", "blank page")
                }
            }
            return Res("success", 200, ms, "", null)
        } finally {
            try { wv.stopLoading(); box.removeView(wv); wv.destroy() } catch (e: Exception) {}
        }
    }
}
