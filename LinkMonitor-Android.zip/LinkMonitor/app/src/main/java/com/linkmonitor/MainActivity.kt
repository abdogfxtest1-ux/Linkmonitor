package com.linkmonitor

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    class Card(val root: LinearLayout, val title: TextView, val box: FrameLayout)

    private lateinit var store: Store
    private lateinit var vpn: Vpn
    private val sites = mutableListOf<String>()
    private val cards = mutableMapOf<String, Card>()
    private val cnt = mutableMapOf<String, IntArray>() // success, failed, blocked, proxy
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var cardsBox: LinearLayout
    private lateinit var urlIn: EditText
    private lateinit var durIn: EditText
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private var job: Job? = null
    private val logs = ArrayDeque<String>()

    private val vpnPerm = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) begin() else toast("لازم توافق على صلاحية VPN")
    }
    private val pickConf = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val d = File(filesDir, "wg").apply { mkdirs() }
        var n = 0
        for (u in uris) {
            val name = nameOf(u) ?: "wg${System.nanoTime()}.conf"
            contentResolver.openInputStream(u)?.use { i ->
                File(d, if (name.endsWith(".conf")) name else "$name.conf").outputStream().use { o -> i.copyTo(o) }
                n++
            }
        }
        toast("تم استيراد $n ملف VPN (الإجمالي ${vpn.confs().size})")
    }
    private val saveCsv = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        uri?.let { contentResolver.openOutputStream(it)?.use { o -> o.write(store.csv().toByteArray()) } }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun nameOf(u: Uri): String? = contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    }
    private fun host(u: String) = u.removePrefix("https://").removePrefix("http://").substringBefore("/")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        store = Store(File(getExternalFilesDir(null), "logs"))
        vpn = Vpn(applicationContext)

        // استئناف العدادات من السجلات
        for (o in store.all()) {
            val c = cnt.getOrPut(o.optString("site")) { IntArray(4) }
            c[idx(o.optString("state"))]++
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        urlIn = EditText(this).apply {
            hint = "ألصق اللينك هنا"; setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val addBtn = Button(this).apply { text = "إضافة"; setOnClickListener { addSite(urlIn.text.toString()); urlIn.setText("") } }
        root.addView(row(urlIn.also { it.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f) }, addBtn))

        durIn = EditText(this).apply { setText("30"); inputType = InputType.TYPE_CLASS_NUMBER; minEms = 3 }
        root.addView(row(TextView(this).apply { text = "مدة المراقبة بعد التحميل (ثانية):" }, durIn))

        startBtn = Button(this).apply { text = "▶ Start"; setOnClickListener { start() } }
        stopBtn = Button(this).apply { text = "■ Stop"; isEnabled = false; setOnClickListener { job?.cancel() } }
        root.addView(row(startBtn, stopBtn))
        val impBtn = Button(this).apply { text = "استيراد VPN"; setOnClickListener { pickConf.launch(arrayOf("*/*")) } }
        val csvBtn = Button(this).apply { text = "تصدير CSV"; setOnClickListener { saveCsv.launch("link-monitor.csv") } }
        root.addView(row(impBtn, csvBtn))

        status = TextView(this).apply { text = "جاهز"; textSize = 14f; setPadding(0, dp(4), 0, dp(4)) }
        root.addView(status)

        cardsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        logView = TextView(this).apply { textSize = 11f; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(cardsBox); addView(logView) }
        root.addView(ScrollView(this).apply { addView(inner) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)

        val saved = getSharedPreferences("m", 0).getString("sites", "") ?: ""
        saved.split("\n").filter { it.isNotBlank() }.forEach { addSite(it) }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { if (it.layoutParams == null) addView(it, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)) else addView(it) }
    }

    private fun idx(state: String) = when (state) { "success" -> 0; "blocked" -> 2; "proxy" -> 3; else -> 1 }

    private fun addSite(raw: String) {
        if (job?.isActive == true) { toast("وقّف الجلسة الأول"); return }
        var u = raw.trim()
        if (u.isEmpty()) return
        if (!u.startsWith("http")) u = "https://$u"
        if (sites.contains(u)) return
        if (sites.size >= 4) { toast("الحد الأقصى 4 مواقع"); return }
        sites.add(u); cnt.getOrPut(u) { IntArray(4) }
        val title = TextView(this).apply { textSize = 12f; setTextColor(Color.BLACK); setBackgroundColor(0xFFE8E8E8.toInt()); setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val box = FrameLayout(this).apply { setBackgroundColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(260)) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(8) }
            addView(title); addView(box)
        }
        title.setOnClickListener { // تكبير/تصغير المعاينة
            val lp = box.layoutParams; lp.height = if (lp.height == dp(260)) dp(520) else dp(260); box.layoutParams = lp
        }
        title.setOnLongClickListener { // مسح الموقع
            if (job?.isActive == true) toast("وقّف الجلسة الأول") else {
                sites.remove(u); cards.remove(u); cardsBox.removeView(card); saveSites()
            }
            true
        }
        cards[u] = Card(card, title, box); cardsBox.addView(card); refresh(u); saveSites()
    }

    private fun saveSites() = getSharedPreferences("m", 0).edit().putString("sites", sites.joinToString("\n")).apply()

    private fun refresh(u: String, tick: Int? = null) {
        val c = cnt[u] ?: IntArray(4)
        val tot = c[0] + c[1]
        val up = if (tot == 0) "—" else "%.1f%%".format(c[0] * 100.0 / tot)
        cards[u]?.title?.text = "${host(u)}   Uptime $up\n✓${c[0]}  ✗${c[1]}  ⛔${c[2]}  ⚠${c[3]}" + (tick?.let { "   ⏱ $it" } ?: "")
    }

    private fun log(s: String) {
        logs.addFirst(SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + "  " + s)
        while (logs.size > 100) logs.removeLast()
        logView.text = logs.joinToString("\n")
    }

    private fun start() {
        if (sites.isEmpty()) { toast("ضيف لينك الأول"); return }
        if (vpn.confs().isNotEmpty()) {
            val i = VpnService.prepare(this)
            if (i != null) { vpnPerm.launch(i); return }
        }
        begin()
    }

    private fun begin() {
        startBtn.isEnabled = false; stopBtn.isEnabled = true
        job = lifecycleScope.launch {
            try { loop() } finally {
                withContext(NonCancellable) { vpn.down() }
                startBtn.isEnabled = true; stopBtn.isEnabled = false; status.text = "متوقف"
            }
        }
    }

    private suspend fun loop() {
        val dur = durIn.text.toString().toIntOrNull()?.coerceIn(5, 600) ?: 30
        var round = 0
        while (true) {
            round++
            val channels: List<File?> = listOf<File?>(null) + vpn.confs()
            val ch = channels[(round - 1) % channels.size]
            val chName = ch?.nameWithoutExtension ?: "direct"
            status.text = "جولة $round • القناة: $chName"
            vpn.down()
            var ip = ""
            var proxyFail = false
            if (ch != null) {
                if (vpn.up(ch)) {
                    delay(1500)
                    var info: Pair<String, String>? = null
                    for (t in 1..2) { info = ipInfo(); if (info != null) break; delay(1500) }
                    if (info == null) proxyFail = true else ip = "${info.first} (${info.second})"
                } else proxyFail = true
            } else {
                ipInfo()?.let { ip = "${it.first} (${it.second})" }
            }
            if (ip.isNotEmpty()) status.text = "جولة $round • $chName • $ip"

            if (proxyFail) {
                for (u in sites.toList()) record(round, u, "proxy", 0, 0, "VPN/IP check failed", chName, ip, null)
                delay(2000); continue
            }
            coroutineScope {
                sites.toList().map { u ->
                    async {
                        val r = Probe(this@MainActivity, cards[u]!!.box).run(u, dur) { t -> refresh(u, t) }
                        record(round, u, r.state, r.status, r.loadMs, r.detail, chName, ip, r.shot)
                    }
                }.awaitAll()
            }
            delay(2000)
        }
    }

    private fun record(round: Int, u: String, state: String, st: Int, ms: Long, detail: String, ch: String, ip: String, shot: Bitmap?) {
        cnt.getOrPut(u) { IntArray(4) }[idx(state)]++
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        var shotName = ""
        if (shot != null) { shotName = "r${round}_${host(u)}_$ts.png"; saveShot(shot, shotName) }
        store.append(JSONObject().put("ts", ts).put("round", round).put("site", u).put("state", state)
            .put("status", st).put("loadMs", ms).put("detail", detail).put("channel", ch).put("ip", ip).put("shot", shotName))
        log("R$round ${host(u)} → $state $detail")
        refresh(u)
    }

    private fun saveShot(bmp: Bitmap, name: String) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LinkMonitor")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
