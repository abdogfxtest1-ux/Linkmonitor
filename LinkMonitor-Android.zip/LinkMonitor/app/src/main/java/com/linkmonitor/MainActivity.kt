package com.linkmonitor

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    class Card(val root: LinearLayout, val title: TextView, val box: FrameLayout, val toggle: Button)

    private lateinit var store: Store
    private lateinit var vpn: Vpn
    private val sites = mutableListOf<String>()
    private val cards = mutableMapOf<String, Card>()
    private val cnt = mutableMapOf<String, IntArray>() // success, failed, blocked, proxy
    private val info = mutableMapOf<String, String>()
    private val active = linkedSetOf<String>()          // الجلسات الشغالة
    private val probeJobs = mutableMapOf<String, Job>()
    private var coord: Job? = null
    private var round = 0
    private var pending: List<String> = emptyList()
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var cardsBox: LinearLayout
    private lateinit var urlIn: EditText
    private lateinit var durIn: EditText
    private lateinit var directCb: CheckBox
    private lateinit var impBtn: Button
    private lateinit var torCb: CheckBox
    private lateinit var torCc: EditText
    private lateinit var tor: Tor
    class Ch(val name: String, val file: File? = null, val cc: String? = null)
    private val logs = ArrayDeque<String>()

    private val vpnPerm = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        val p = pending; pending = emptyList()
        if (it.resultCode == RESULT_OK) p.forEach { u -> startSite(u) } else toast("لازم توافق على صلاحية VPN")
    }
    private val pickConf = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val d = File(filesDir, "wg").apply { mkdirs() }
        var n = 0
        for (u in uris) {
            val name = nameOf(u) ?: "wg${System.nanoTime()}.conf"
            contentResolver.openInputStream(u)?.use { i ->
                File(d, if (name.endsWith(".conf")) name else "$name.conf").outputStream().use { o -> i.copyTo(o) }
                n++
            }
        }
        updateImp(); toast("تم استيراد $n ملف (الإجمالي ${vpn.confs().size})")
    }
    private val saveCsv = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        uri?.let { contentResolver.openOutputStream(it)?.use { o -> o.write(store.csv().toByteArray()) } }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun nameOf(u: Uri): String? = contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    }
    private fun host(u: String) = u.removePrefix("https://").removePrefix("http://").substringBefore("/")
    private fun idx(state: String) = when (state) { "success" -> 0; "blocked" -> 2; "proxy" -> 3; else -> 1 }
    private fun updateImp() { impBtn.text = "استيراد VPN (${vpn.confs().size})" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        store = Store(File(getExternalFilesDir(null), "logs"))
        vpn = Vpn(applicationContext)
        tor = Tor(applicationContext)
        for (o in store.all()) cnt.getOrPut(o.optString("site")) { IntArray(4) }[idx(o.optString("state"))]++

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        urlIn = EditText(this).apply {
            hint = "ألصق اللينك هنا"; setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        }
        val addBtn = Button(this).apply { text = "إضافة"; setOnClickListener { addSite(urlIn.text.toString()); urlIn.setText("") } }
        root.addView(row(urlIn, addBtn))

        durIn = EditText(this).apply { setText("30"); inputType = InputType.TYPE_CLASS_NUMBER; minEms = 3 }
        root.addView(row(TextView(this).apply { text = "مدة المراقبة بعد التحميل (ثانية):" }, durIn))
        directCb = CheckBox(this).apply { text = "ضمّ الاتصال المباشر (بدون VPN) في التبديل"; isChecked = true }
        root.addView(directCb)
        torCb = CheckBox(this).apply { text = "استخدم Tor كمصدر IP (بدون حساب، أبطأ)" }
        root.addView(torCb)
        torCc = EditText(this).apply {
            setText("us,de,nl,fr,gb"); hint = "أكواد الدول بحرفين، مفصولة بفاصلة"; setSingleLine()
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        root.addView(torCc)

        root.addView(row(
            Button(this).apply { text = "▶ تشغيل الكل"; setOnClickListener { startAll() } },
            Button(this).apply { text = "■ إيقاف الكل"; setOnClickListener { stopAll() } }))
        impBtn = Button(this).apply {
            setOnClickListener { pickConf.launch(arrayOf("*/*")) }
            setOnLongClickListener {
                if (coord?.isActive == true) toast("وقّف الجلسات الأول")
                else { File(filesDir, "wg").deleteRecursively(); updateImp(); toast("اتمسحت ملفات الـ VPN") }
                true
            }
        }
        updateImp()
        root.addView(row(impBtn,
            Button(this).apply { text = "ازاي أجيب VPN؟"; setOnClickListener { help() } },
            Button(this).apply { text = "تصدير CSV"; setOnClickListener { saveCsv.launch("link-monitor.csv") } }))

        status = TextView(this).apply { text = "جاهز"; textSize = 14f; setPadding(0, dp(4), 0, dp(4)) }
        root.addView(status)
        cardsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        logView = TextView(this).apply { textSize = 11f; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(cardsBox); addView(logView) }
        root.addView(ScrollView(this).apply { addView(inner) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)

        (getSharedPreferences("m", 0).getString("sites", "") ?: "").split("\n").filter { it.isNotBlank() }.forEach { addSite(it) }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { if (it.layoutParams == null) addView(it, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)) else addView(it) }
    }

    private fun help() {
        AlertDialog.Builder(this)
            .setTitle("ملفات VPN مجانية (Proton)")
            .setMessage("التطبيق محتاج ملفات WireGuard عشان يغيّر الـ IP والدولة. مجاناً:\n\n" +
                "1) اعمل حساب Proton VPN مجاني\n" +
                "2) سجّل دخول من account.protonvpn.com\n" +
                "3) افتح Downloads ثم WireGuard configuration\n" +
                "4) اختار Android، واختار سيرفر/دولة، واضغط Create ثم Download\n" +
                "5) كرر لدول وسيرفرات مختلفة (كل ملف = IP مختلف)\n" +
                "6) ارجع هنا واضغط «استيراد VPN» واختار الملفات\n\n" +
                "بديل بدون حساب: فعّل خيار Tor وحط أكواد الدول.\n" +
                "الضغط المطوّل على زر الاستيراد يمسح كل الملفات.")
            .setPositiveButton("فتح Proton") { _, _ -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://account.protonvpn.com/downloads"))) }
            .setNegativeButton("تمام", null).show()
    }

    private fun addSite(raw: String) {
        var u = raw.trim()
        if (u.isEmpty()) return
        if (!u.startsWith("http")) u = "https://$u"
        if (sites.contains(u)) return
        if (sites.size >= 4) { toast("الحد الأقصى 4 مواقع"); return }
        sites.add(u); cnt.getOrPut(u) { IntArray(4) }
        val title = TextView(this).apply { textSize = 12f; setTextColor(Color.BLACK); setBackgroundColor(0xFFE8E8E8.toInt()); setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val box = FrameLayout(this).apply { setBackgroundColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(260)) }
        val toggle = Button(this).apply { setOnClickListener { if (u in active) stopSite(u) else startSite(u) } }
        val del = Button(this).apply { text = "✕ حذف"; setOnClickListener { removeSite(u) } }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(8) }
            addView(title); addView(box); addView(row(toggle, del))
        }
        title.setOnClickListener { // تكبير/تصغير المعاينة
            val lp = box.layoutParams; lp.height = if (lp.height == dp(260)) dp(520) else dp(260); box.layoutParams = lp
        }
        cards[u] = Card(card, title, box, toggle); cardsBox.addView(card); refresh(u); saveSites()
    }

    private fun removeSite(u: String) {
        stopSite(u)
        cards.remove(u)?.let { cardsBox.removeView(it.root) }
        sites.remove(u); saveSites()
    }

    private fun saveSites() = getSharedPreferences("m", 0).edit().putString("sites", sites.joinToString("\n")).apply()

    private fun refresh(u: String, tick: Int? = null) {
        val c = cnt[u] ?: IntArray(4)
        val tot = c[0] + c[1]
        val up = if (tot == 0) "—" else "%.1f%%".format(c[0] * 100.0 / tot)
        val on = u in active
        cards[u]?.title?.text = "${if (on) "🟢" else "⚪"} ${host(u)}   Uptime $up\n✓${c[0]}  ✗${c[1]}  ⛔${c[2]}  ⚠${c[3]}" +
            (tick?.let { "   ⏱ $it" } ?: "") + "\n" + (info[u] ?: "متوقف")
        cards[u]?.toggle?.text = if (on) "■ Stop" else "▶ Start"
    }

    private fun log(s: String) {
        logs.addFirst(SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + "  " + s)
        while (logs.size > 100) logs.removeLast()
        logView.text = logs.joinToString("\n")
    }

    private fun ensurePerm(list: List<String>): Boolean {
        if (vpn.confs().isEmpty()) return true
        val i = VpnService.prepare(this) ?: return true
        pending = list; vpnPerm.launch(i); return false
    }

    private fun startAll() {
        if (sites.isEmpty()) { toast("ضيف لينك الأول"); return }
        if (!ensurePerm(sites.toList())) return
        sites.toList().forEach { startSite(it) }
    }

    private fun stopAll() = sites.toList().forEach { stopSite(it) }

    private fun startSite(u: String) {
        if (u in active) return
        if (!ensurePerm(listOf(u))) return
        active.add(u); info[u] = "⏳ بانتظار الجولة"; refresh(u)
        if (coord?.isActive != true) {
            val prev = coord
            coord = lifecycleScope.launch {
                try { prev?.join(); loop() } finally {
                    withContext(NonCancellable) { vpn.down(); WebProxy.clear(this@MainActivity); tor.stop() }
                    status.text = "متوقف"
                }
            }
        }
    }

    private fun stopSite(u: String) {
        if (u !in active) return
        active.remove(u)
        probeJobs.remove(u)?.cancel()
        info[u] = "متوقف"; refresh(u)
        if (active.isEmpty()) coord?.cancel()
    }

    private suspend fun loop() {
        while (active.isNotEmpty()) {
            round++
            val confs = vpn.confs()
            val ccs = if (torCb.isChecked) torCc.text.toString().split(",").map { it.trim().lowercase() }.filter { it.length == 2 } else emptyList()
            val channels = mutableListOf<Ch>()
            if (directCb.isChecked || (confs.isEmpty() && ccs.isEmpty())) channels.add(Ch("direct"))
            confs.forEach { channels.add(Ch(it.nameWithoutExtension, file = it)) }
            ccs.forEach { channels.add(Ch("tor-$it", cc = it)) }
            val ch = channels[(round - 1) % channels.size]
            val chName = ch.name
            status.text = "جولة $round • القناة: $chName • جلسات شغالة: ${active.size}"
            vpn.down()
            var ip = ""
            var proxyFail = false
            if (ch.cc != null) {
                tor.start()
                val ready = tor.waitReady(180_000) { p -> status.text = "جولة $round • Tor يتصل... $p%" }
                if (ready && tor.useExit(ch.cc) && WebProxy.set(this@MainActivity, tor.socksPort)) {
                    delay(4000)
                    var inf: Pair<String, String>? = null
                    for (t in 1..3) { inf = ipInfo(tor.socksPort); if (inf != null) break; delay(3000) }
                    if (inf == null) proxyFail = true else ip = "${inf.first} (${inf.second})"
                } else proxyFail = true
            } else {
                WebProxy.clear(this@MainActivity)
                if (ch.file != null) {
                    if (vpn.up(ch.file)) {
                        delay(1500)
                        var inf: Pair<String, String>? = null
                        for (t in 1..2) { inf = ipInfo(); if (inf != null) break; delay(1500) }
                        if (inf == null) proxyFail = true else ip = "${inf.first} (${inf.second})"
                    } else proxyFail = true
                } else {
                    ipInfo()?.let { ip = "${it.first} (${it.second})" }
                }
            }
            if (ip.isNotEmpty()) status.text = "جولة $round • $chName • $ip • جلسات: ${active.size}"
            val snap = active.toList()
            if (proxyFail) {
                for (u in snap) if (u in active) { info[u] = "⚠ فشل VPN: $chName"; record(round, u, "proxy", 0, 0, "VPN/IP check failed", chName, ip, null) }
                delay(2000); continue
            }
            for (u in snap) { info[u] = "جولة $round • $chName • $ip"; refresh(u) }
            val dur = durIn.text.toString().toIntOrNull()?.coerceIn(5, 600) ?: 30
            coroutineScope {
                for (u in snap) {
                    val card = cards[u] ?: continue
                    probeJobs[u] = launch {
                        try {
                            val r = Probe(this@MainActivity, card.box).run(u, dur) { t -> refresh(u, t) }
                            if (u in active) record(round, u, r.state, r.status, r.loadMs, r.detail, chName, ip, r.shot)
                        } catch (e: CancellationException) { throw e }
                        catch (e: Exception) { log("خطأ ${host(u)}: ${e.message}") }
                    }
                }
            }
            snap.forEach { probeJobs.remove(it) }
            delay(2000)
        }
    }

    private fun record(round: Int, u: String, state: String, st: Int, ms: Long, detail: String, ch: String, ip: String, shot: Bitmap?) {
        cnt.getOrPut(u) { IntArray(4) }[idx(state)]++
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        var shotName = ""
        if (shot != null) { shotName = "r${round}_${host(u)}_$ts.png"; saveShot(shot, shotName) }
        store.append(JSONObject().put("ts", ts).put("round", round).put("site", u).put("state", state)
            .put("status", st).put("loadMs", ms).put("detail", detail).put("channel", ch).put("ip", ip).put("shot", shotName))
        log("R$round ${host(u)} [$ch] → $state $detail")
        refresh(u)
    }

    private fun saveShot(bmp: Bitmap, name: String) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LinkMonitor")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
