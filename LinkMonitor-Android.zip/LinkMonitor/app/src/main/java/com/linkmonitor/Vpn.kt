package com.linkmonitor

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** VPN داخل التطبيق نفسه (WireGuard) — يشمل التطبيق فقط وليس باقي الموبايل. */
class Vpn(private val ctx: Context) {
    private val backend = GoBackend(ctx)
    private val tunnel = object : Tunnel {
        override fun getName(): String = "lm0"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    fun confs(): List<File> =
        (File(ctx.filesDir, "wg").listFiles() ?: emptyArray()).filter { it.name.endsWith(".conf") }.sortedBy { it.name }

    suspend fun up(f: File): Boolean = withContext(Dispatchers.IO) {
        try {
            var txt = f.readText()
            if (!txt.contains("IncludedApplications", true)) {
                txt = txt.replaceFirst("[Interface]", "[Interface]\nIncludedApplications = ${ctx.packageName}")
            }
            val cfg = Config.parse(txt.byteInputStream())
            backend.setState(tunnel, Tunnel.State.UP, cfg)
            true
        } catch (e: Exception) { false }
    }

    suspend fun down() {
        withContext(Dispatchers.IO) {
            try { backend.setState(tunnel, Tunnel.State.DOWN, null) } catch (e: Exception) {}
        }
    }
}

/** يرجّع (IP, الدولة) أو null لو فشل. socksPort>0 يعني الفحص عن طريق Tor. */
suspend fun ipInfo(socksPort: Int = 0): Pair<String, String>? = withContext(Dispatchers.IO) {
    try {
        val px = if (socksPort > 0) java.net.Proxy(java.net.Proxy.Type.SOCKS, java.net.InetSocketAddress("127.0.0.1", socksPort)) else java.net.Proxy.NO_PROXY
        val c = URL("https://ipwho.is/").openConnection(px) as HttpURLConnection
        val to = if (socksPort > 0) 20000 else 6000
        c.connectTimeout = to; c.readTimeout = to
        val j = JSONObject(c.inputStream.bufferedReader().readText())
        if (j.optBoolean("success", true)) Pair(j.getString("ip"), j.optString("country", "?")) else null
    } catch (e: Exception) { null }
}
