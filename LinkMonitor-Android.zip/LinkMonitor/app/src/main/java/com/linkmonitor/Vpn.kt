package com.linkmonitor

import android.content.Context
import android.os.SystemClock
import com.wireguard.android.backend.BackendException
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

/** VPN داخل التطبيق نفسه (WireGuard) — يشمل التطبيق فقط وليس باقي الموبايل. */
class Vpn(private val ctx: Context) {
    private val backend = GoBackend(ctx)
    private val tunnel = object : Tunnel {
        override fun getName(): String = "lm0"
        override fun onStateChange(newState: Tunnel.State) {}
    }
    // بورتات WireGuard اللي سيرفرات Proton بتسمع عليها؛ لو المزوّد قافل بورت نجرب غيره
    private val altPorts = listOf(51820, 443, 4500, 500, 1224, 88)
    private val goodPort = mutableMapOf<String, Int>()

    fun confs(): List<File> =
        (File(ctx.filesDir, "wg").listFiles() ?: emptyArray()).filter { it.name.endsWith(".conf") }.sortedBy { it.name }

    /** يشغّل الملف ويتأكد إن السيرفر رد فعلاً (handshake). يرجّع null لو تمام، أو سبب الفشل. */
    suspend fun up(f: File): String? = withContext(Dispatchers.IO) {
        val txt = try { f.readText() } catch (e: Exception) { return@withContext "مش قادر يقرا الملف" }
        val m = Regex("(?im)^\\s*Endpoint\\s*=\\s*(\\S+):(\\d+)\\s*$").find(txt) ?: return@withContext "الملف مفيهوش Endpoint"
        val orig = m.groupValues[2].toInt()
        val ports = (listOfNotNull(goodPort[f.name], orig) + altPorts).distinct()
        var last = "السيرفر مردّش"
        for (p in ports) {
            var t = txt.replaceRange(m.groups[2]!!.range, p.toString())
            if (!t.contains("IncludedApplications", true)) {
                t = t.replaceFirst("[Interface]", "[Interface]\nIncludedApplications = ${ctx.packageName}")
            }
            val cfg = try { Config.parse(t.byteInputStream()) } catch (e: Exception) { return@withContext "الملف بايظ: ${e.message}" }
            val err = setUp(cfg)
            if (err != null) { last = err; continue }
            if (handshake(6000)) { goodPort[f.name] = p; return@withContext null }
            last = "السيرفر مردّش (جرّبنا بورتات ${ports.joinToString(",")})"
        }
        down()
        last
    }

    private suspend fun setUp(cfg: Config): String? {
        // أول تشغيل للـ VpnService ساعات بياخد أكتر من ثانيتين فالمكتبة بترمي UNABLE_TO_START_VPN
        for (t in 1..3) {
            try { backend.setState(tunnel, Tunnel.State.UP, cfg); return null }
            catch (e: BackendException) { if (t == 3) return "VPN: ${e.reason}"; delay(1500) }
            catch (e: Exception) { return "VPN: ${e.message}" }
        }
        return "VPN مش راضي يشتغل"
    }

    /** WireGuard مش بيعمل handshake غير لما يعدّي ترافيك، فنبعت اتصال صغير ونستنى رد السيرفر. */
    private suspend fun handshake(timeoutMs: Long): Boolean {
        val t0 = SystemClock.elapsedRealtime()
        while (SystemClock.elapsedRealtime() - t0 < timeoutMs) {
            try { Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1000) } } catch (e: Exception) {}
            try {
                val s = backend.getStatistics(tunnel)
                if (s.peers().any { k -> (s.peer(k)?.latestHandshakeEpochMillis() ?: 0L) > 0L }) return true
            } catch (e: Exception) {}
            delay(500)
        }
        return false
    }

    suspend fun down() {
        withContext(Dispatchers.IO) {
            try { backend.setState(tunnel, Tunnel.State.DOWN, null) } catch (e: Exception) {}
        }
    }
}

/** يرجّع (IP, الدولة) أو null لو فشل. socksPort>0 يعني الفحص عن طريق Tor. بيجرب أكتر من خدمة. */
suspend fun ipInfo(socksPort: Int = 0): Pair<String, String>? = withContext(Dispatchers.IO) {
    val px = if (socksPort > 0) java.net.Proxy(java.net.Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", socksPort)) else java.net.Proxy.NO_PROXY
    val to = if (socksPort > 0) 20000 else 8000
    fun get(u: String): String {
        val c = URL(u).openConnection(px) as HttpURLConnection
        c.connectTimeout = to; c.readTimeout = to
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) LinkMonitor")
        try { return c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }
    val tries = listOf<() -> Pair<String, String>?>(
        {
            val kv = get("https://www.cloudflare.com/cdn-cgi/trace").lines().mapNotNull { l -> l.split("=", limit = 2).takeIf { it.size == 2 } }.associate { it[0] to it[1] }
            kv["ip"]?.let { Pair(it, kv["loc"] ?: "?") }
        },
        { val j = JSONObject(get("https://ipwho.is/")); if (j.optBoolean("success", true)) Pair(j.getString("ip"), j.optString("country", "?")) else null },
        { val j = JSONObject(get("https://ipapi.co/json/")); j.optString("ip").takeIf { it.isNotEmpty() }?.let { Pair(it, j.optString("country_name", "?")) } },
    )
    for (t in tries) { try { t()?.let { return@withContext it } } catch (e: Exception) {} }
    null
}
