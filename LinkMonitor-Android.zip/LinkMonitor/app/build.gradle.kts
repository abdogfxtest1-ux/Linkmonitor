plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.linkmonitor"
    compileSdk = 34
    defaultConfig { applicationId = "com.linkmonitor"; minSdk = 29; targetSdk = 34; versionCode = 5; versionName = "0.5"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { useLegacyPackaging = true } }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.wireguard.android:tunnel:1.0.20230706")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("info.guardianproject:tor-android:0.4.8.11")
    implementation("info.guardianproject:jtorctl:0.4.5.7")
    implementation("com.netzarchitekten:IPtProxy:5.7.0")
}
